<?php $anatomy_int_ext = $this->options; ?>
var anaconfig = {
	'default':{
		'outlineColor':'<?php echo $anatomy_int_ext['outlineColor']; ?>',
	}<?php echo (isset($anatomy_int_ext['url_1']))?',':''; ?><?php $i = 1; 	while (isset($anatomy_int_ext['url_'.$i])) { ?>'ana<?php echo $i; ?>':{
		'hover': '<?php echo str_replace(array("\n","\r","\r\n","'"),array('','','','’'), is_array($anatomy_int_ext['info_'.$i]) ?
				array_map('stripslashes_deep', $anatomy_int_ext['info_'.$i]) : stripslashes($anatomy_int_ext['info_'.$i])); ?>',
		'url':'<?php echo $anatomy_int_ext['url_'.$i]; ?>',
		'target':'<?php echo $anatomy_int_ext['turl_'.$i]; ?>',
		'enabled':<?php echo $anatomy_int_ext['enabled_'.$i]=='1'?'true':'false'; ?>,
		}
		<?php echo (isset($anatomy_int_ext['url_'.($i+1)]))?',':''; ?><?php $i++;} ?>
}