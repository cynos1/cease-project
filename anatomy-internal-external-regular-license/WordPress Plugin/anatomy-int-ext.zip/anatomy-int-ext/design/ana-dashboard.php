<?php $anatomy_int_ext = $this->options; ?>
<form method="post" action="<?php echo admin_url( '/' ); ?>admin.php?page=anatomy-int-ext">
<div id="anatomy-admin">
  <div id="anatomy-header">
    <p class="anatomy-shortcode">Insert this shortcode <input type="text" value="[anatomy_int_ext]" readonly> into any page or post to display the interactive drawing. &nbsp; | &nbsp; <span class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></span></p>
  </div>
  <div id="anatomy-page">
    <div class="anatomy-col-lt">
      <div id="anatomy-preview">
        <?php include 'anatomy.php'; ?>
      </div>
      <div class="anatomy-settings">
        <div class="box-header individ-i">Customization of the First Side</div>
        <div class="box-body">

          <div class="org-area"><p class="area-name">HEAD</p>
            <span class="chkbx"><input type="checkbox" name="enabled_1" value="1" <?php if ($anatomy_int_ext['enabled_1'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_1" value="<?php echo $anatomy_int_ext['url_1']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_1">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_1'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_1'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_1'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_1"><?php echo $anatomy_int_ext['info_1']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT EYE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_2" value="1" <?php if ($anatomy_int_ext['enabled_2'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_2" value="<?php echo $anatomy_int_ext['url_2']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_2">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_2'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_2'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_2'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_2"><?php echo $anatomy_int_ext['info_2']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT EYE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_3" value="1" <?php if ($anatomy_int_ext['enabled_3'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_3" value="<?php echo $anatomy_int_ext['url_3']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_3">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_3'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_3'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_3'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_3"><?php echo $anatomy_int_ext['info_3']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT EAR</p>
            <span class="chkbx"><input type="checkbox" name="enabled_4" value="1" <?php if ($anatomy_int_ext['enabled_4'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_4" value="<?php echo $anatomy_int_ext['url_4']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_4">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_4'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_4'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_4'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_4"><?php echo $anatomy_int_ext['info_4']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT EAR</p>
            <span class="chkbx"><input type="checkbox" name="enabled_5" value="1" <?php if ($anatomy_int_ext['enabled_5'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_5" value="<?php echo $anatomy_int_ext['url_5']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_5">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_5'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_5'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_5'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_5"><?php echo $anatomy_int_ext['info_5']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">NOSE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_6" value="1" <?php if ($anatomy_int_ext['enabled_6'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_6" value="<?php echo $anatomy_int_ext['url_6']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_6">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_6'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_6'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_6'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_6"><?php echo $anatomy_int_ext['info_6']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">MOUTH</p>
            <span class="chkbx"><input type="checkbox" name="enabled_7" value="1" <?php if ($anatomy_int_ext['enabled_7'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_7" value="<?php echo $anatomy_int_ext['url_7']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_7">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_7'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_7'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_7'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_7"><?php echo $anatomy_int_ext['info_7']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">NECK</p>
            <span class="chkbx"><input type="checkbox" name="enabled_8" value="1" <?php if ($anatomy_int_ext['enabled_8'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_8" value="<?php echo $anatomy_int_ext['url_8']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_8">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_8'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_8'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_8'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_8"><?php echo $anatomy_int_ext['info_8']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">CHEST</p>
            <span class="chkbx"><input type="checkbox" name="enabled_9" value="1" <?php if ($anatomy_int_ext['enabled_9'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_9" value="<?php echo $anatomy_int_ext['url_9']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_9">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_9'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_9'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_9'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_9"><?php echo $anatomy_int_ext['info_9']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">ABDOMEN</p>
            <span class="chkbx"><input type="checkbox" name="enabled_10" value="1" <?php if ($anatomy_int_ext['enabled_10'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_10" value="<?php echo $anatomy_int_ext['url_10']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_10">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_10'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_10'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_10'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_10"><?php echo $anatomy_int_ext['info_10']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">PELVIS</p>
            <span class="chkbx"><input type="checkbox" name="enabled_11" value="1" <?php if ($anatomy_int_ext['enabled_11'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_11" value="<?php echo $anatomy_int_ext['url_11']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_11">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_11'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_11'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_11'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_11"><?php echo $anatomy_int_ext['info_11']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">PUBIS</p>
            <span class="chkbx"><input type="checkbox" name="enabled_12" value="1" <?php if ($anatomy_int_ext['enabled_12'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_12" value="<?php echo $anatomy_int_ext['url_12']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_12">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_12'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_12'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_12'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_12"><?php echo $anatomy_int_ext['info_12']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT SHOULDER</p>
            <span class="chkbx"><input type="checkbox" name="enabled_13" value="1" <?php if ($anatomy_int_ext['enabled_13'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_13" value="<?php echo $anatomy_int_ext['url_13']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_13">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_13'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_13'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_13'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_13"><?php echo $anatomy_int_ext['info_13']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT SHOULDER</p>
            <span class="chkbx"><input type="checkbox" name="enabled_14" value="1" <?php if ($anatomy_int_ext['enabled_14'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_14" value="<?php echo $anatomy_int_ext['url_14']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_14">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_14'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_14'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_14'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_14"><?php echo $anatomy_int_ext['info_14']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT ARM</p>
            <span class="chkbx"><input type="checkbox" name="enabled_15" value="1" <?php if ($anatomy_int_ext['enabled_15'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_15" value="<?php echo $anatomy_int_ext['url_15']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_15">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_15'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_15'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_15'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_15"><?php echo $anatomy_int_ext['info_15']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT ARM</p>
            <span class="chkbx"><input type="checkbox" name="enabled_16" value="1" <?php if ($anatomy_int_ext['enabled_16'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_16" value="<?php echo $anatomy_int_ext['url_16']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_16">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_16'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_16'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_16'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_16"><?php echo $anatomy_int_ext['info_16']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT ELBOW</p>
            <span class="chkbx"><input type="checkbox" name="enabled_17" value="1" <?php if ($anatomy_int_ext['enabled_17'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_17" value="<?php echo $anatomy_int_ext['url_17']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_17">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_17'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_17'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_17'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_17"><?php echo $anatomy_int_ext['info_17']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">ELBOW</p>
            <span class="chkbx"><input type="checkbox" name="enabled_18" value="1" <?php if ($anatomy_int_ext['enabled_18'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_18" value="<?php echo $anatomy_int_ext['url_18']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_18">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_18'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_18'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_18'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_18"><?php echo $anatomy_int_ext['info_18']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT FOREARM</p>
            <span class="chkbx"><input type="checkbox" name="enabled_19" value="1" <?php if ($anatomy_int_ext['enabled_19'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_19" value="<?php echo $anatomy_int_ext['url_19']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_19">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_19'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_19'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_19'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_19"><?php echo $anatomy_int_ext['info_19']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT FOREARM</p>
            <span class="chkbx"><input type="checkbox" name="enabled_20" value="1" <?php if ($anatomy_int_ext['enabled_20'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_20" value="<?php echo $anatomy_int_ext['url_20']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_20">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_20'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_20'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_20'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_20"><?php echo $anatomy_int_ext['info_20']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT WRIST</p>
            <span class="chkbx"><input type="checkbox" name="enabled_21" value="1" <?php if ($anatomy_int_ext['enabled_21'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_21" value="<?php echo $anatomy_int_ext['url_21']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_21">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_21'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_21'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_21'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_21"><?php echo $anatomy_int_ext['info_21']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT WRIST</p>
            <span class="chkbx"><input type="checkbox" name="enabled_22" value="1" <?php if ($anatomy_int_ext['enabled_22'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_22" value="<?php echo $anatomy_int_ext['url_22']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_22">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_22'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_22'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_22'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_22"><?php echo $anatomy_int_ext['info_22']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT HAND</p>
            <span class="chkbx"><input type="checkbox" name="enabled_23" value="1" <?php if ($anatomy_int_ext['enabled_23'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_23" value="<?php echo $anatomy_int_ext['url_23']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_23">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_23'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_23'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_23'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_23"><?php echo $anatomy_int_ext['info_23']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT HAND</p>
            <span class="chkbx"><input type="checkbox" name="enabled_24" value="1" <?php if ($anatomy_int_ext['enabled_24'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_24" value="<?php echo $anatomy_int_ext['url_24']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_24">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_24'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_24'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_24'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_24"><?php echo $anatomy_int_ext['info_24']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT THIGH</p>
            <span class="chkbx"><input type="checkbox" name="enabled_25" value="1" <?php if ($anatomy_int_ext['enabled_25'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_25" value="<?php echo $anatomy_int_ext['url_25']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_25">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_25'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_25'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_25'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_25"><?php echo $anatomy_int_ext['info_25']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT THIGH</p>
            <span class="chkbx"><input type="checkbox" name="enabled_26" value="1" <?php if ($anatomy_int_ext['enabled_26'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_26" value="<?php echo $anatomy_int_ext['url_26']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_26">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_26'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_26'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_26'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_26"><?php echo $anatomy_int_ext['info_26']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT KNEE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_27" value="1" <?php if ($anatomy_int_ext['enabled_27'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_27" value="<?php echo $anatomy_int_ext['url_27']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_27">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_27'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_27'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_27'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_27"><?php echo $anatomy_int_ext['info_27']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT KNEE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_28" value="1" <?php if ($anatomy_int_ext['enabled_28'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_28" value="<?php echo $anatomy_int_ext['url_28']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_28">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_28'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_28'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_28'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_28"><?php echo $anatomy_int_ext['info_28']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT LEG</p>
            <span class="chkbx"><input type="checkbox" name="enabled_29" value="1" <?php if ($anatomy_int_ext['enabled_29'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_29" value="<?php echo $anatomy_int_ext['url_29']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_29">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_29'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_29'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_29'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_29"><?php echo $anatomy_int_ext['info_29']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT LEG</p>
            <span class="chkbx"><input type="checkbox" name="enabled_30" value="1" <?php if ($anatomy_int_ext['enabled_30'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_30" value="<?php echo $anatomy_int_ext['url_30']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_30">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_30'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_30'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_30'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_30"><?php echo $anatomy_int_ext['info_30']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT ANKLE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_31" value="1" <?php if ($anatomy_int_ext['enabled_31'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_31" value="<?php echo $anatomy_int_ext['url_31']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_31">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_31'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_31'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_31'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_31"><?php echo $anatomy_int_ext['info_31']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT ANKLE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_32" value="1" <?php if ($anatomy_int_ext['enabled_32'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_32" value="<?php echo $anatomy_int_ext['url_32']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_32">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_32'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_32'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_32'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_32"><?php echo $anatomy_int_ext['info_32']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">RIGHT FOOT</p>
            <span class="chkbx"><input type="checkbox" name="enabled_33" value="1" <?php if ($anatomy_int_ext['enabled_33'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_33" value="<?php echo $anatomy_int_ext['url_33']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_33">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_33'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_33'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_33'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_33"><?php echo $anatomy_int_ext['info_33']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LEFT FOOT</p>
            <span class="chkbx"><input type="checkbox" name="enabled_34" value="1" <?php if ($anatomy_int_ext['enabled_34'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_34" value="<?php echo $anatomy_int_ext['url_34']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_34">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_34'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_34'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_34'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_34"><?php echo $anatomy_int_ext['info_34']; ?></textarea></p></div>
            </div>
          </div>

        </div><!-- box-body / for areas -->
      </div><!-- anatomy-settings -->
        
      <div class="anatomy-settings">
        <div class="box-header individ-i">Customization of the Second Side</div>
        <div class="box-body">

          <div class="org-area"><p class="area-name">BRAIN</p>
            <span class="chkbx"><input type="checkbox" name="enabled_35" value="1" <?php if ($anatomy_int_ext['enabled_35'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_35" value="<?php echo $anatomy_int_ext['url_35']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_35">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_35'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_35'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_35'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_35"><?php echo $anatomy_int_ext['info_35']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LARYNX</p>
            <span class="chkbx"><input type="checkbox" name="enabled_36" value="1" <?php if ($anatomy_int_ext['enabled_36'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_36" value="<?php echo $anatomy_int_ext['url_36']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_36">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_36'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_36'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_36'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_36"><?php echo $anatomy_int_ext['info_36']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">THYROID</p>
            <span class="chkbx"><input type="checkbox" name="enabled_37" value="1" <?php if ($anatomy_int_ext['enabled_37'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_37" value="<?php echo $anatomy_int_ext['url_37']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_37">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_37'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_37'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_37'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_37"><?php echo $anatomy_int_ext['info_37']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">TRACHEA</p>
            <span class="chkbx"><input type="checkbox" name="enabled_38" value="1" <?php if ($anatomy_int_ext['enabled_38'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_38" value="<?php echo $anatomy_int_ext['url_38']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_38">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_38'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_38'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_38'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_38"><?php echo $anatomy_int_ext['info_38']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LUNGS</p>
            <span class="chkbx"><input type="checkbox" name="enabled_39" value="1" <?php if ($anatomy_int_ext['enabled_39'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_39" value="<?php echo $anatomy_int_ext['url_39']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_39">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_39'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_39'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_39'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_39"><?php echo $anatomy_int_ext['info_39']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">STOMACH</p>
            <span class="chkbx"><input type="checkbox" name="enabled_40" value="1" <?php if ($anatomy_int_ext['enabled_40'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_40" value="<?php echo $anatomy_int_ext['url_40']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_40">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_40'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_40'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_40'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_40"><?php echo $anatomy_int_ext['info_40']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">HEART</p>
            <span class="chkbx"><input type="checkbox" name="enabled_41" value="1" <?php if ($anatomy_int_ext['enabled_41'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_41" value="<?php echo $anatomy_int_ext['url_41']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_41">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_41'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_41'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_41'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_41"><?php echo $anatomy_int_ext['info_41']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">SPLEEN</p>
            <span class="chkbx"><input type="checkbox" name="enabled_42" value="1" <?php if ($anatomy_int_ext['enabled_42'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_42" value="<?php echo $anatomy_int_ext['url_42']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_42">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_42'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_42'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_42'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_42"><?php echo $anatomy_int_ext['info_42']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LIVER</p>
            <span class="chkbx"><input type="checkbox" name="enabled_43" value="1" <?php if ($anatomy_int_ext['enabled_43'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_43" value="<?php echo $anatomy_int_ext['url_43']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_43">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_43'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_43'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_43'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_43"><?php echo $anatomy_int_ext['info_43']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">LARGE INTESTINE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_44" value="1" <?php if ($anatomy_int_ext['enabled_44'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_44" value="<?php echo $anatomy_int_ext['url_44']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_44">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_44'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_44'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_44'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_44"><?php echo $anatomy_int_ext['info_44']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">SMALL INTESTINE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_45" value="1" <?php if ($anatomy_int_ext['enabled_45'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_45" value="<?php echo $anatomy_int_ext['url_45']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_45">
                    <option value="same_window" <?php if($anatomy_int_ext['turl_45'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_int_ext['turl_45'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_int_ext['turl_45'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_45"><?php echo $anatomy_int_ext['info_45']; ?></textarea></p></div>
            </div>
          </div>

        </div><!-- box-body / for areas -->
      </div><!-- anatomy-settings / for areas -->
    </div><!-- anatomy-col-lt -->

    <!-- General anatomy Colors -->
    <div class="anatomy-col-rt">
      <div class="anatomy-settings">
        <div class="box-header shape-icon">General Settings</div>
        <div class="box-body">
          <div class="general-box"><span class="general-set i-border">Outline Color</span><input type="text" name="outlineColor" value="<?php echo $anatomy_int_ext['outlineColor']; ?>" class="color-field" /></div>
        </div><!-- box-body -->
      </div><!-- anatomy-settings -->
      <p><strong>Hint:</strong> you can hide the outline by setting its value as <strong><i>transparent</i></strong></p>
    </div><!-- anatomy-col-rt -->

    <input type="hidden" name="anatomy_int_ext">
      <?php
      settings_fields(__FILE__);
      do_settings_sections(__FILE__);
      ?>
    <p class="anatomy-btns"><span class="submit"><input type="submit" name="restore_default" id="submit" class="button" value="Restore Default"></span></p>
    <div class="scroll-top"><span class="scroll-top-icon"></span></div>
    <!--scroll-top script-->
    <script>
      jQuery(function(){jQuery(document).on( 'scroll', function(){ if (jQuery(window).scrollTop() > 100) {jQuery('.scroll-top').addClass('show');} else {jQuery('.scroll-top').removeClass('show');}});jQuery('.scroll-top').on('click', scrollToTop);});function scrollToTop() {verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;element = jQuery('body');offset = element.offset();offsetTop = offset.top -32;jQuery('html, body').animate({scrollTop: offsetTop}, 500, 'linear');}
    </script>

  </div><!-- anatomy-page -->
</div><!-- anatomy-admin -->
</form>
