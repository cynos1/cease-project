<?php
/*
Plugin Name: Anatomy [Int/Ext]
Plugin URI: https://www.humananatomyillustrations.com/human-anatomy-internal-external-illustration.html
Description: Customize each body part (link, hover info., etc) through the dashboard and use the shortcode in your page(s).
Version: 2.3
Author: Interactive Anatomy Apps
Author URI: https://www.humananatomyillustrations.com/
*/

class ANATOMYINTEXT {

	public function __construct(){
		$this->constant();
		$this->options = get_option( 'anatomy_int_ext' );
		add_action( 'admin_menu', array($this, 'anatomy_int_ext_options_page') );
	 	add_action( 'admin_footer', array( $this,'add_js_to_wp_footer') );
	 	add_action( 'wp_footer', array($this,'add_span_tag') );
		add_action( 'admin_enqueue_scripts', array($this,'init_admin_script') );
		add_shortcode( 'anatomy_int_ext', array($this, 'anatomy_int_ext') );
		$this->default = array(
			'outlineColor' => '#ff8080',
		);
		foreach (array(
			'HEAD', 'RIGHT EYE', 'LEFT EYE', 'RIGHT EAR', 'LEFT EAR', 'NOSE', 'MOUTH', 'NECK', 'CHEST', 'ABDOMEN', 'PELVIS', 'PUBIS', 'RIGHT SHOULDER', 'LEFT SHOULDER', 'RIGHT ARM', 'LEFT ARM', 'RIGHT ELBOW', 'ELBOW', 'RIGHT FOREARM', 'LEFT FOREARM', 'RIGHT WRIST', 'LEFT WRIST', 'RIGHT HAND', 'LEFT HAND', 'RIGHT THIGH', 'LEFT THIGH', 'RIGHT KNEE', 'LEFT KNEE', 'RIGHT LEG', 'LEFT LEG', 'RIGHT ANKLE', 'LEFT ANKLE', 'RIGHT FOOT', 'LEFT FOOT', 'BRAIN', 'LARYNX', 'THYROID', 'TRACHEA', 'LUNGS', 'STOMACH', 'HEART', 'SPLEEN', 'LIVER', 'LARGE INTESTINE', 'SMALL INTESTINE'
		) as $k=>$area) {
			$this->default['url_'.($k+1)] = '';
			$this->default['turl_'.($k+1)] = 'same_window';
			$this->default['info_'.($k+1)] = $area;
			$this->default['enabled_'.($k+1)] = 1;
		}
		if(isset($_POST['anatomy_int_ext']) && !isset($_POST['preview_anatomy'])){
			update_option('anatomy_int_ext', array_map('stripslashes_deep', $_POST));
			$this->options = array_map('stripslashes_deep', $_POST);
		}
		if(isset($_POST['anatomy_int_ext']) && isset($_POST['restore_default'])){
			update_option('anatomy_int_ext', $this->default);
			$this->options = $this->default;
		}
		if(!is_array($this->options)){
			$this->options = $this->default;
		}
	}

	protected function constant(){
		define( 'ANATOMYINTEXT_VERSION', '1.0' );
		define( 'ANATOMYINTEXT_DIR', plugin_dir_path( __FILE__ ) );
		define( 'ANATOMYINTEXT_URL', plugin_dir_url( __FILE__ ) );
	}

	public function anatomy_int_ext(){
		ob_start();
		include 'design/anatomy.php';
		?>
		<script type="text/javascript">
			<?php include 'anatomy-settings.php'; ?>
		</script>
		<?php
		wp_enqueue_style( 'anatomystyle-frontend', ANATOMYINTEXT_URL . 'illustration-style.css', false, '1.0', 'all' );
		wp_enqueue_script( 'interact-script', ANATOMYINTEXT_URL . 'interact-script.js', array('jquery'), 10, '1.0', true );
		wp_enqueue_script( 'spots-settings', ANATOMYINTEXT_URL . 'spots-settings.js', array('jquery'), 10, '1.0', true );
		$html = ob_get_clean();
		return $html;
	}

	public function anatomy_int_ext_options_page() {
		add_menu_page('Anatomy [Int/Ext]', 'Anatomy [Int/Ext]', 'manage_options', 'anatomy-int-ext', array($this, 'options_screen'), ANATOMYINTEXT_URL . 'images/anatomy-icon.png');
	}

	public function admin_ajax_url(){
		$url_action = admin_url( '/' ) . 'admin-ajax.php';
		echo '<div style="display:none" id="wpurl">'. $url_action.'</div>';
	}

	public function options_screen(){ ?>
		<script type="text/javascript">
			<?php include 'anatomy-settings.php'; ?>
		</script>
	<?php include 'design/ana-dashboard.php';
	}

	public function add_js_to_wp_footer(){ ?>
	<span id="anatip" style="margin-top:-32px"></span>
	<?php }

	public function add_span_tag(){
		?>
		<span id="anatip"></span>
		<?php
	}

	public function stripslashes_deep($value) {
		$value = is_array($value) ?
		array_map(array($this, 'stripslashes_deep'), $value) : stripslashes($value);
		return $value;
	}

	public function init_admin_script(){
		if(isset($_GET['page']) && $_GET['page'] == 'anatomy-int-ext'):
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style('thickbox');
		wp_enqueue_script('thickbox');
		wp_enqueue_script( 'media-upload');
		wp_enqueue_style( 'anatomy-style', ANATOMYINTEXT_URL . 'anatomy-dashboard.css', false, '1.0', 'all' );
		wp_enqueue_style( 'anatomystyle', ANATOMYINTEXT_URL . 'illustration-style.css', false, '1.0', 'all' );
		wp_enqueue_style( 'wp-tinyeditor', ANATOMYINTEXT_URL . 'tinyeditor.css', false, '1.0', 'all' );
		wp_enqueue_script( 'interact-script', ANATOMYINTEXT_URL . 'interact-script.js', array('jquery'), 10, '1.0', true );
		wp_enqueue_script( 'spots-settings', ANATOMYINTEXT_URL . 'spots-settings.js', array('jquery'), 10, '1.0', true );
		wp_enqueue_script( 'anatomy-tiny.editor', ANATOMYINTEXT_URL . 'js/tinymce.min.js', 10, '1.0', true );
		wp_enqueue_script( 'anatomy-script', ANATOMYINTEXT_URL . 'js/scripts.js', array( 'wp-color-picker' ), false, true );
		endif;
	}
}

$anatomy_int_ext = new ANATOMYINTEXT();